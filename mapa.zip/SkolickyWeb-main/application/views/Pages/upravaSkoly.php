<style>
.ram{
    width: 100%;
    height:81%;
    margin-left: 40%;

}
</style>
<br>
<br>
<br>

<div class="ram">Zde bude úprava školy.</div>
